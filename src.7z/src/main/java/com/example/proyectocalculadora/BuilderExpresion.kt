package com.example.proyectocalculadora

class BuilderExpresion(txt: String) {
    fun build(): BuilderExpresion? {
        var expresion:BuilderExpresion? = null
        return expresion
    }

    fun evaluate(): Double {
        var resul:Double = 0.0
        return resul
    }

}
