package com.example.proyectocalculadora

class NotANumberException : Throwable() {

}
